globalThis.SESSIONSIGNAL_CONFIG = Object.freeze({"url":"https://YOUR_PROJECT.supabase.co","publishableKey":"sb_publishable_REPLACE_ME"});
