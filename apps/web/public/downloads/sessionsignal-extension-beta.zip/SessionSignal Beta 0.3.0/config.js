globalThis.SESSIONSIGNAL_CONFIG = Object.freeze({"url":"https://exsnmwlkzteifestibqs.supabase.co","publishableKey":"sb_publishable_8h6k8ol8Kbsceufo9zVQ8A_vWzHoMDK"});
